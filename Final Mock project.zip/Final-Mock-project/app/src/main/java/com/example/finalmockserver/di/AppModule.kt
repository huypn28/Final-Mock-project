package com.example.finalmockserver.di

object AppModule {
}